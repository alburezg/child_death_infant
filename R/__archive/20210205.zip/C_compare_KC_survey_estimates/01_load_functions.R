source("../functions.R")

# Data wrangling
wrangling <- c(
  "tidyverse"
  , "countrycode"
  # , "plyr"
  , "readxl"
)

library2(wrangling)
